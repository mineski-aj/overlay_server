@echo off
setlocal enabledelayedexpansion
title MOV to WebM Converter

echo ===============================
echo   MOV to WebM Converter
echo ===============================
echo.

:: Change to the folder where this .bat file lives
cd /d "%~dp0"

:: Check if ffmpeg is already available
where ffmpeg >nul 2>&1
if %errorlevel% == 0 (
    echo FFmpeg found on PATH. Skipping install.
    goto convert
)

:: Check if ffmpeg is bundled in the same folder
if exist "%~dp0ffmpeg\bin\ffmpeg.exe" (
    echo FFmpeg found in local folder.
    set "PATH=%~dp0ffmpeg\bin;%PATH%"
    goto convert
)

:: FFmpeg not found — download and install it
echo FFmpeg not found. Installing now...
echo.

:: Check for winget
where winget >nul 2>&1
if %errorlevel% == 0 (
    echo Using winget to install FFmpeg...
    winget install --id Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements
    if %errorlevel% == 0 (
        echo FFmpeg installed successfully via winget.
        :: Refresh PATH from registry
        for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYS_PATH=%%B"
        for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USR_PATH=%%B"
        set "PATH=!SYS_PATH!;!USR_PATH!"
        goto convert
    )
)

:: Fallback: download FFmpeg zip via PowerShell
echo Downloading FFmpeg via PowerShell...
powershell -Command "& {
    $url = 'https://github.com/GyanD/codexffmpeg/releases/download/6.1.1/ffmpeg-6.1.1-essentials_build.zip';
    $out = '%~dp0ffmpeg.zip';
    Write-Host 'Downloading FFmpeg (this may take a minute)...';
    Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing;
    Write-Host 'Extracting...';
    Expand-Archive -Path $out -DestinationPath '%~dp0ffmpeg_tmp' -Force;
    $inner = Get-ChildItem '%~dp0ffmpeg_tmp' -Directory | Select-Object -First 1;
    Move-Item $inner.FullName '%~dp0ffmpeg' -Force;
    Remove-Item '%~dp0ffmpeg_tmp' -Recurse -Force;
    Remove-Item $out -Force;
    Write-Host 'Done.';
}"

if exist "%~dp0ffmpeg\bin\ffmpeg.exe" (
    set "PATH=%~dp0ffmpeg\bin;%PATH%"
    echo FFmpeg ready.
) else (
    echo.
    echo ERROR: Could not install FFmpeg automatically.
    echo Please download it manually from https://ffmpeg.org/download.html
    echo and place ffmpeg.exe in a folder on your PATH.
    echo.
    pause
    exit /b 1
)

:convert
echo.
echo Scanning for .mov files in:
echo %~dp0
echo.

set success=0
set failed=0
set found=0

for %%F in ("%~dp0*.mov" "%~dp0*.MOV") do (
    set /a found+=1
)

if %found% == 0 (
    echo No .mov files found in this folder.
    echo Make sure this .bat file is in the same folder as your .mov files.
    echo.
    pause
    exit /b 0
)

for %%F in ("%~dp0*.mov" "%~dp0*.MOV") do (
    set "input=%%F"
    set "output=%%~dpnF.webm"
    echo Converting: %%~nxF -^> %%~nF.webm
    ffmpeg -i "%%F" -c:v libvpx-vp9 -crf 33 -b:v 0 -c:a libopus -y "!output!" -loglevel error -stats
    if !errorlevel! == 0 (
        echo   Done!
        set /a success+=1
    ) else (
        echo   FAILED.
        set /a failed+=1
    )
    echo.
)

echo ===============================
echo Conversion complete!
echo   Succeeded: %success%
echo   Failed:    %failed%
echo ===============================
echo.
pause
