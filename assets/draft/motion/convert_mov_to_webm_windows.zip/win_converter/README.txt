MOV to WebM Converter — Windows
================================

USAGE
-----
1. Copy convert_mov_to_webm.bat into the folder containing your .mov files.
2. Double-click it to run.
3. The first run will automatically install FFmpeg if it's not already on your system.
4. Converted .webm files will appear in the same folder.

REQUIREMENTS
------------
- Windows 10 or later
- Internet connection (only needed on first run if FFmpeg isn't installed)

HOW FFMPEG GETS INSTALLED
--------------------------
The script tries three methods in order:
  1. Uses FFmpeg if already installed on your system PATH.
  2. Uses winget (built into Windows 10/11) to install it silently.
  3. Downloads a portable FFmpeg build directly into the script's folder as a fallback.

After the first run, FFmpeg will be available and no further downloads are needed.

NOTES
-----
- Output files are saved alongside the originals with the same name, just .webm extension.
- Uses VP9 video codec + Opus audio for high-quality, web-compatible WebM files.
- If a .webm file with the same name already exists, it will be overwritten.
