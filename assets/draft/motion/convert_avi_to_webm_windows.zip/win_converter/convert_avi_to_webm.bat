@echo off
setlocal enabledelayedexpansion
title AVI to WebM Converter

echo ===============================
echo   AVI to WebM Converter
echo ===============================
echo.

cd /d "%~dp0"

:: Check for Python
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not on PATH.
    echo Download it from https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

:: Check for ffmpeg
where ffmpeg >nul 2>&1
if %errorlevel% neq 0 (
    if exist "%~dp0ffmpeg\bin\ffmpeg.exe" (
        set "PATH=%~dp0ffmpeg\bin;%PATH%"
    ) else (
        echo FFmpeg not found. Downloading now...
        powershell -Command "& {
            $url = 'https://github.com/GyanD/codexffmpeg/releases/download/6.1.1/ffmpeg-6.1.1-essentials_build.zip';
            $out = '%~dp0ffmpeg.zip';
            Write-Host 'Downloading FFmpeg...';
            Invoke-WebRequest -Uri $url -OutFile $out -UseBasicParsing;
            Write-Host 'Extracting...';
            Expand-Archive -Path $out -DestinationPath '%~dp0ffmpeg_tmp' -Force;
            $inner = Get-ChildItem '%~dp0ffmpeg_tmp' -Directory | Select-Object -First 1;
            Move-Item $inner.FullName '%~dp0ffmpeg' -Force;
            Remove-Item '%~dp0ffmpeg_tmp' -Recurse -Force;
            Remove-Item $out -Force;
            Write-Host 'FFmpeg ready.';
        }"
        set "PATH=%~dp0ffmpeg\bin;%PATH%"
    )
)

python "%~dp0convert_avi_to_webm.py"

echo.
pause
